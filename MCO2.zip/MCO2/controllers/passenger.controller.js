const express = require('express')
const router = express.Router()

const Passenger = require('../models/passenger.model')

module.exports = router