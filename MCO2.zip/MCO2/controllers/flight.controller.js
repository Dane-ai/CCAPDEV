const express = require('express')
const router = express.Router()

const Flight = require('../models/flight.model')

module.exports = router