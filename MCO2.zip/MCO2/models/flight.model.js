const mongoose = require('mongoose');
const { Passenger } = require('./passenger.model');
const { Seat } = require('./seat.model');

const Flight = new mongoose.Schema({
  flightNum: String,
  airline: String,
  origin: String,
  destination: String,
  departureDate: String,
  returnDate: String,
  departureTime: String,
  arrivalTime: String,
  passengerCount: String,
  referenceNum: String,
  price: String,
  passengers: {
    type: [Passenger.schema],
  },
  seats: {
    type: [Seat.schema],
  },
});

module.exports = mongoose.model('Flight', FlightSchema);

