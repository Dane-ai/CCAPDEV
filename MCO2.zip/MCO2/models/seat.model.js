const mongoose = require('mongoose');


const Seat = new mongoose.Schema({
  seatNumber: String,
  isVacant: String,
});

module.exports = mongoose.model('Seat', SeatSchema);