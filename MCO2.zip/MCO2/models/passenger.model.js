const mongoose = require('mongoose');

const Passenger = new mongoose.Schema({
  firstName: String,
  lastName: String,
  passportID: String,
  flightNum: String,
  meal: String,
  seat: String,
  baggage: String,
  referenceNum: String,
});

module.exports = mongoose.model('Passenger', PassengerSchema);