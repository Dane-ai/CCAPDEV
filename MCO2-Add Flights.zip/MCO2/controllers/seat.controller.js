const express = require('express')
const router = express.Router()

const Seat = require('../models/seat.model')

module.exports = router