# Node.js CRUD with MongoDB, Express and Handlebars

This a demo project from YouTube Tutorial given below

 ## How it works ?
 
 :tv: Video tutorial on this same topic
 Url : https://youtu.be/9VHTDhwo9u0
 
 <a href="http://www.youtube.com/watch?feature=player_embedded&v=9VHTDhwo9u0
" target="_blank"><img src="http://img.youtube.com/vi/9VHTDhwo9u0/0.jpg" 
alt="Video demonstrating CRUD Operation in Node.js App with MongoDB Express and Handlebars" width="500" height="400" border="10" /></a>
